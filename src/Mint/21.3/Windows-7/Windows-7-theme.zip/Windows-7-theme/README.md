[![built-with-azurra-framework](https://github.com/B00merang-Project/B00merang-Project.github.io/blob/master/resources/badges/azurra/badge_smaller.png)](https://github.com/B00merang-Project/Azurra_framework)

# Windows 7
Linux theme based on the apperance of Windows 7

### Preview
![win-7](https://b00merang.weebly.com/uploads/1/6/8/1/16813022/906611131-orig-orig_2_orig.png)

### Supported platforms
- Any GTK-based desktop
- Cinnamon
- Gnome
- MATE
- Xfce

### Manual installation
Go to releases, download the latest `.zip` file and extract it to the themes directory i.e. `/home/USERNAME/.themes`
